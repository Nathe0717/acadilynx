var express = require('express');
var router = express.Router();
var path = require('path');
var port = 3000;

/* Kiosk */
router.get('/kiosk', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../public/kiosk/AcadilynxKiosk.html'));
});

/* Staff */
router.get('/staff', function (req, res, next) {
    res.sendFile(path.join(__dirname, '../public/employees/AcadilynxStaffnAdmin.html'));
});


module.exports = router;
