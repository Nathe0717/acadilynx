var express = require('express');
var router = express.Router();

const db = require("../db/devAConnectionWU");
const rateLimit = require('../middleware/rateLimit');
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//Queue gate (opening hours + daily limit)
async function queueGate(role, table) {
    const open = process.env.QUEUE_OPEN;
    const close = process.env.QUEUE_CLOSE;
    if (open && close) {
        const now = new Date();
        const hhmm = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
        if (hhmm < open || hhmm >= close) {
            return { status: 403, message: 'The queue is closed right now. Please come back during opening hours.', reason: 'closed' };
        }
    }
    const [[setting]] = await db.query('select daily_limit from QueueSettings where queue_role = ?', [role]);
    const envLimit = parseInt(process.env.QUEUE_DAILY_LIMIT, 10);
    const limit = setting && setting.daily_limit ? setting.daily_limit : (Number.isInteger(envLimit) ? envLimit : null);
    if (limit) {
        const [[issued]] = await db.query(`select count(*) as n from ${table} where date_inquired >= curdate()`);
        if (issued.n >= limit) {
            return { status: 403, message: "Today's ticket limit has been reached. Please come back tomorrow.", reason: 'limit' };
        }
    }
    return null;
}

//Ticket validation (shared by both ticket routes). Returns { error } or { values }.
//Limits match the database columns: names 60, email 50 (Registrar) / 60 (Cashier), contact 09 + 9 digits.
function validateTicket(body, isCashier) {
    const NAME_RE = /^(?=(?:.*\p{L}){2})[\p{L}\s.'’-]+$/u;
    const name = (v) => {
        const s = String(v ?? '').trim();
        return s.length <= 60 && NAME_RE.test(s) ? s : null;
    };
    const student = name(body.student);
    const guardian = name(body.guardian);
    const contact = String(body.contact ?? '').trim();
    const email = String(body.email ?? '').trim();
    const emailMax = isCashier ? 60 : 50;
    const transactions = Array.isArray(body.transactions)
        ? body.transactions.join(', ')
        : String(body.transactions ?? '').trim();

    if (!student) return { error: 'Please enter a valid student name (letters only, up to 60 characters).' };
    if (!guardian) return { error: 'Please enter a valid parent/guardian name (letters only, up to 60 characters).' };
    if (!/^09\d{9}$/.test(contact)) return { error: 'Contact number must be 11 digits starting with 09.' };
    if (email.length > emailMax || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return { error: 'Please enter a valid email address (up to ' + emailMax + ' characters).' };
    }
    if (!transactions || transactions.length > 2000) return { error: 'Please select at least one transaction.' };

    const values = { student, guardian, contact, email, transactions };
    if (isCashier) {
        const fee = Math.round(Number(body.fee) * 100) / 100;
        if (!(fee > 0) || fee > 99999999.99) return { error: 'Please enter a valid amount.' };
        values.fee = fee;
    }
    return { values };
}

//Post Registrar
router.post("/kiosk_RegistrarPost", async (req, res) => {
    try {
        const checked = validateTicket(req.body, false);
        if (checked.error) return res.status(400).json({ message: checked.error });
        const { student, guardian, contact, email, transactions } = checked.values;

        const blocked = await queueGate('Registrar', 'RegistrarInquiries');
        if (blocked) return res.status(blocked.status).json({ message: blocked.message, reason: blocked.reason });

        const [result] = await db.query('insert into RegistrarInquiries (student_name, inquirer_name, guardian_contact, guardian_email, services_selected) values (?, ?, ?, ?, ?)', [student, guardian, contact, email, transactions]);

        res.status(201).json({
            idview: result.insertId
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Post Cashier
router.post("/kiosk_CashierPost", async (req, res) => {
    try {
        const checked = validateTicket(req.body, true);
        if (checked.error) return res.status(400).json({ message: checked.error });
        const { student, guardian, fee, contact, email, transactions } = checked.values;

        const blocked = await queueGate('Cashier', 'CashierInquiries');
        if (blocked) return res.status(blocked.status).json({ message: blocked.message, reason: blocked.reason });

        const [result] = await db.query('insert into CashierInquiries (student_name, inquirer_name, amount, guardian_contact, guardian_email, services_selected) values (?, ?, ?, ?, ?, ?)', [student, guardian, fee, contact, email, transactions]);
        res.status(201).json({
            idview: result.insertId
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Verify Enrolled Student
router.post('/kiosk_VerifyStudent', rateLimit({ max: 30, windowMs: 60 * 1000, message: 'Too many checks. Please wait a minute and try again.' }), async (req, res) => {
    try {
        const { student, grade, schoolYear } = req.body || {};
        if (!student || !grade || !schoolYear) {
            return res.status(400).json({ message: 'Please complete all fields.' });
        }

        const [rows] = await db.query(
            `SELECT 1 FROM Students
             WHERE LOWER(TRIM(student_name_full)) = LOWER(TRIM(?))
               AND LOWER(TRIM(grade_level))  = LOWER(TRIM(?))
               AND school_year = ?
             LIMIT 1`,
            [student, grade, schoolYear]
        );

        // Only say yes/no. Never return the student's record to the kiosk.
        res.json({ found: rows.length > 0 });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Could not check the student record.' });
    }
});

//Queue Status (kiosk checks this before letting a customer start)
router.get('/kiosk_QueueStatus', async (req, res) => {
    const queues = {
        registrar: ['Registrar', 'RegistrarInquiries'],
        cashier: ['Cashier', 'CashierInquiries']
    };
    const queue = queues[req.query.queue];
    if (!queue) {
        return res.status(400).json({ message: 'Invalid queue' });
    }
    try {
        const blocked = await queueGate(queue[0], queue[1]);
        res.json(blocked ? { open: false, reason: blocked.reason, message: blocked.message } : { open: true });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Could not check the queue.' });
    }
});

module.exports = router;
