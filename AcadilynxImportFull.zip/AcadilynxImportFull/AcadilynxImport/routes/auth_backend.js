var express = require('express');
var router = express.Router();
const bcrypt = require('bcryptjs');
const db = require("../db/devAConnectionWU");
const rateLimit = require('../middleware/rateLimit');

//A real bcrypt hash to compare against when the email is unknown, so a wrong email takes as long as a wrong password
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);

//Login
router.post("/login", rateLimit({ max: 20, windowMs: 10 * 60 * 1000, message: 'Too many login attempts. Please wait a few minutes and try again.' }), async (req, res) => {
    const email = (req.body.email || '').trim().toLowerCase();
    const password = req.body.password || '';
    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required.' });
    }
    try {
        const [rows] = await db.query(
            'select employee_ID, employee_fullName, employee_role, employee_password, employee_status from EmployeesList where employee_email = ?',
            [email]
        );
        const user = rows[0];
        const hashOk = await bcrypt.compare(password, user ? user.employee_password : DUMMY_HASH);
        if (!user || !hashOk || user.employee_status !== 'active') {
            return res.status(401).json({ message: 'Invalid email or password.' });
        }
        //Login history (a failed log write must never block a valid login)
        try {
            await db.query('insert into LoginLog (employee_ID) values (?)', [user.employee_ID]);
        } catch (logError) {
            console.error(logError);
        }
        req.session.regenerate((err) => {
            if (err) {
                console.error(err);
                return res.status(500).json({ message: 'session error' });
            }
            req.session.user = { id: user.employee_ID, name: user.employee_fullName, role: user.employee_role };
            res.json(req.session.user);
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Who am I (lets the page restore the login after a refresh)
router.get("/me", async (req, res) => {
    if (!req.session.user) return res.status(401).json({ message: 'Not logged in.' });
    try {
        //Re-check the account, so a deactivated staff member is not restored by a page refresh
        const [rows] = await db.query('select employee_status from EmployeesList where employee_ID = ?', [req.session.user.id]);
        if (!rows.length || rows[0].employee_status !== 'active') {
            req.session.destroy(() => { });
            return res.status(401).json({ message: 'Account is not active.' });
        }
        res.json(req.session.user);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Logout
router.post("/logout", async (req, res) => {
    try {
        if (req.session.user) {
            //Give the counter back and reopen it, so the next staff member does not inherit a closed counter
            await db.query('update Counters set staff_id = null, last_seen = null, is_closed = 0 where staff_id = ?', [req.session.user.id]);
        }
    } catch (error) {
        console.error(error);
    }
    req.session.destroy(() => {
        res.clearCookie('connect.sid');
        res.json({ message: 'Logged out.' });
    });
})

module.exports = router;
