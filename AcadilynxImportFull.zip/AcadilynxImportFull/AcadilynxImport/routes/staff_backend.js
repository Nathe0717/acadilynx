var express = require('express');
var router = express.Router();

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const requireRole = require('../middleware/requireRole');

const db = require("../db/devAConnectionWU");
/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

//Validation helpers
//Contact: 09 followed by 9 digits (11 digits total). Names 60 characters, email 50 (matches the database columns).
const CONTACT_RE = /^09\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function cleanText(value, max) {
    const s = String(value ?? '').trim();
    return s && s.length <= max ? s : null;
}

//Names: letters, spaces and . ' - only, at least 2 letters, up to 60 characters
const NAME_RE = /^(?=(?:.*\p{L}){2})[\p{L}\s.'’-]+$/u;
function cleanName(value) {
    const s = String(value ?? '').trim();
    return s.length <= 60 && NAME_RE.test(s) ? s : null;
}

//Temp passwords: 10 characters, no look-alikes (no O/0, l/1/I), easy to read out and type
const TEMP_PW_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
function makeTempPassword(length = 10) {
    let out = '';
    for (let i = 0; i < length; i++) out += TEMP_PW_CHARS[crypto.randomInt(TEMP_PW_CHARS.length)];
    return out;
}

//Add Staff
router.post("/staff_addStaff", requireRole('Admin'), async (req, res) => {
    const { role } = req.body;
    const employeedbID = cleanText(req.body.employeedbID, 60);
    const fullName = cleanName(req.body.fullName);
    const contact = String(req.body.contact ?? '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    if (req.body.fullName && !fullName) {
        return res.status(400).json({ message: "Please enter a valid name: letters, spaces, and . ' - only." });
    }
    if (!employeedbID || !fullName || !contact || !email) {
        return res.status(400).json({ message: 'Missing fields' });
    }
    if (!CONTACT_RE.test(contact)) {
        return res.status(400).json({ message: 'Contact number must be 11 digits starting with 09.' });
    }
    if (email.length > 50 || !EMAIL_RE.test(email)) {
        return res.status(400).json({ message: 'Please enter a valid email address (up to 50 characters).' });
    }
    if (role !== 'Registrar' && role !== 'Cashier') {
        return res.status(400).json({ message: 'Invalid role' });
    }
    try {
        const tempPassword = makeTempPassword();
        const hash = await bcrypt.hash(tempPassword, 10);
        await db.query(
            'insert into EmployeesList (employee_ID, employee_fullName, employee_role, employee_password, employee_contact, employee_email, employee_status) values (?, ?, ?, ?, ?, ?, ?)',
            [employeedbID, fullName, role, hash, contact, email, 'active']
        );
        res.status(201).json({ message: 'Staff user added!', tempPassword });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            const emailClash = /employee_email/.test(error.sqlMessage || '');
            return res.status(409).json({ message: emailClash ? 'That email is already in use.' : 'That staff ID already exists. Please try again.' });
        }
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Patch Status
router.patch("/staff_statusChange/:employeedbID", requireRole('Admin'), async (req, res) => {
    const { employeedbID } = req.params;
    try {
        const { status } = req.body;
        if (status !== 'active' && status !== 'deactivated') {
            return res.status(400).json({
                message: 'Invalid status'
            })
        }
        //Admin accounts cannot be changed from here (an admin could otherwise lock themselves out)
        const [result] = await db.query("update EmployeesList set employee_status = ? where employee_ID = ? and employee_role <> 'Admin'", [status, employeedbID]);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: 'User not found'
            })
        }

        if (status === 'deactivated') {
            //Free any counter the deactivated staff member was holding
            await db.query('update Counters set staff_id = null, last_seen = null, is_closed = 0 where staff_id = ?', [employeedbID]);
        }

        res.status(200).json({
            message: 'Status update successful!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Patch Info
router.patch("/staff_infoChange/:employeedbID", requireRole('Admin'), async (req, res) => {
    const { employeedbID } = req.params;
    try {
        const { role } = req.body;
        const fullName = cleanName(req.body.fullName);
        const contact = String(req.body.contact ?? '').trim();
        const email = String(req.body.email || '').trim().toLowerCase();
        if (req.body.fullName && !fullName) {
            return res.status(400).json({ message: "Please enter a valid name: letters, spaces, and . ' - only." });
        }
        if (!fullName || !contact || !email) {
            return res.status(400).json({ message: 'Missing fields' });
        }
        if (!CONTACT_RE.test(contact)) {
            return res.status(400).json({ message: 'Contact number must be 11 digits starting with 09.' });
        }
        if (email.length > 50 || !EMAIL_RE.test(email)) {
            return res.status(400).json({ message: 'Please enter a valid email address (up to 50 characters).' });
        }
        if (role !== 'Registrar' && role !== 'Cashier') {
            return res.status(400).json({ message: 'Invalid role' });
        }
        //Admin accounts cannot be edited or demoted from here
        const [result] = await db.query("update EmployeesList set employee_fullName = ?, employee_role = ?, employee_contact = ?, employee_email = ? where employee_ID = ? and employee_role <> 'Admin'", [fullName, role, contact, email, employeedbID]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({ message: 'Info update successful!' });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ message: 'That email is already in use.' });
        }
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Staff Display
router.get("/staff_staffDisplay", requireRole('Admin'), async (req, res) => {
    try {
        const [rows] = await db.query(
            "select employee_ID, employee_fullName, employee_role, employee_contact, employee_email, employee_status from EmployeesList where employee_role <> 'Admin'"
        );
        //if password is displayed at some point, revert to this.
        //const [result] = await db.query('select * from EmployeesList where employee_role <> \'Admin\'');

        res.json(rows);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Registrar Display
router.get("/staff_riDisplay", requireRole('Admin', 'Registrar'), async (req, res) => {
    try {
        const [result] = await db.query('select * from RegistrarInquiries order by date_inquired desc limit 1000');

        res.json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})
//Cashier Display
router.get("/staff_ciDisplay", requireRole('Admin', 'Cashier'), async (req, res) => {
    try {
        const [result] = await db.query('select * from CashierInquiries order by date_inquired desc limit 1000');

        res.json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue Snapshot
async function queueSnapshot(table, idCol) {
    const [serving] = await db.query(
        `select ${idCol} as id from ${table}
         where queue_status = 'serving' and date_inquired >= curdate()
         order by called_at desc limit 1`
    );
    const [[waiting]] = await db.query(
        `select count(*) as n from ${table}
         where queue_status = 'waiting' and date_inquired >= curdate()`
    );
    return { ticket: serving.length ? String(serving[0].id) : null, waiting: waiting.n };
}

//Queue Status
router.get("/staff_queueStatus", requireRole('Admin', 'Registrar', 'Cashier'), async (req, res) => {
    try {
        const registrar = await queueSnapshot('RegistrarInquiries', 'RInq_ID');
        const cashier = await queueSnapshot('CashierInquiries', 'CInq_ID');
        res.json({ registrar, cashier });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue based on Role (staff portal)
function queueTableFor(role) {
    if (role === 'Registrar') return { table: 'RegistrarInquiries', idCol: 'RInq_ID' };
    if (role === 'Cashier') return { table: 'CashierInquiries', idCol: 'CInq_ID' };
    return null;
}
function parseCounter(value) {
    const n = Number(value);
    return Number.isInteger(n) && n >= 1 && n <= 3 ? n : null;
}
//Who holds this counter, and is it closed? (null = no such counter)
async function counterState(role, counter) {
    const [rows] = await db.query(
        'select staff_id, is_closed from Counters where counter_role = ? and counter_no = ?',
        [role, counter]
    );
    return rows[0] || null;
}
//Every queue action requires the staff member to actually hold the counter they name
function notYourCounter(res) {
    return res.status(409).json({ message: 'You are no longer signed in to this counter.' });
}

//Queue Mine (staff portal page)
router.get("/staff_queueMine", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.query.counter);
    if (!q || !counter) {
        return res.status(400).json({ message: 'Invalid counter' });
    }
    try {
        //Heartbeat: keeps this counter claimed, and tells the page if it no longer holds it
        const [beat] = await db.query(
            'update Counters set last_seen = now(3) where counter_role = ? and counter_no = ? and staff_id = ?',
            [req.session.user.role, counter, req.session.user.id]
        );
        if (beat.affectedRows === 0) {
            return notYourCounter(res);
        }
        const state = await counterState(req.session.user.role, counter);
        const [serving] = await db.query(
            `select ${q.idCol} as ticket, inquirer_name as name from ${q.table}
             where queue_status = 'serving' and counter_no = ? and date_inquired >= curdate()
             order by called_at desc limit 1`,
            [counter]
        );
        const [waiting] = await db.query(
            `select ${q.idCol} as ticket, inquirer_name as name,
                    timestampdiff(minute, date_inquired, now()) as waitMins
             from ${q.table}
             where queue_status = 'waiting' and date_inquired >= curdate()
             order by ${q.idCol}`
        );
        const [held] = await db.query(
            `select ${q.idCol} as ticket, inquirer_name as name from ${q.table}
             where queue_status = 'held' and counter_no = ? and date_inquired >= curdate()
             order by ${q.idCol}`,
            [counter]
        );
        const [done] = await db.query(
            `select ${q.idCol} as ticket, inquirer_name as name, queue_status as status,
                    coalesce(completed_at, called_at, date_inquired) as doneAt
             from ${q.table}
             where queue_status in ('completed', 'cancelled') and counter_no = ? and date_inquired >= curdate()
             order by doneAt desc limit 50`,
            [counter]
        );
        const [[setting]] = await db.query('select daily_limit from QueueSettings where queue_role = ?', [req.session.user.role]);
        const [[issued]] = await db.query(`select count(*) as n from ${q.table} where date_inquired >= curdate()`);
        res.json({
            serving: serving.length ? { ticket: String(serving[0].ticket), name: serving[0].name } : null,
            waiting: waiting.map(w => ({ ticket: String(w.ticket), name: w.name, waitMins: w.waitMins })),
            onHold: held.map(h => ({ ticket: String(h.ticket), name: h.name })),
            history: done.map(d => ({
                ticket: String(d.ticket), name: d.name, type: req.session.user.role,
                status: d.status, doneAt: d.doneAt
            })),
            dailyLimit: setting ? setting.daily_limit : null,
            ticketsToday: issued.n,
            closed: !!(state && state.is_closed)
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Call Next
router.post("/staff_callNext", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.body.counter);
    if (!q || !counter) {
        return res.status(400).json({ message: 'Invalid counter' });
    }
    try {
        const state = await counterState(req.session.user.role, counter);
        if (!state || state.staff_id !== req.session.user.id) {
            return notYourCounter(res);
        }
        if (state.is_closed) {
            return res.status(409).json({ message: 'This counter is closed. Reopen it to call customers.' });
        }
        const [busy] = await db.query(
            `select 1 from ${q.table}
             where queue_status = 'serving' and counter_no = ? and date_inquired >= curdate() limit 1`,
            [counter]
        );
        if (busy.length) {
            return res.status(409).json({ message: 'This counter is already serving a customer.' });
        }
        //One statement picks and claims the oldest waiting ticket, so two counters can never get the same one
        const [result] = await db.query(
            `update ${q.table} set queue_status = 'serving', counter_no = ?, called_at = now()
             where queue_status = 'waiting' and date_inquired >= curdate()
             order by ${q.idCol} limit 1`,
            [counter]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'No customers waiting.' });
        }
        res.json({ message: 'Next customer called.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Counters Status
router.get("/staff_counters", requireRole('Registrar', 'Cashier'), async (req, res) => {
    try {
        const [rows] = await db.query(
            `select c.counter_no, c.staff_id, e.employee_fullName as staff_name,
                    (c.staff_id is not null and c.last_seen > now(3) - interval 90 second) as occupied
             from Counters c left join EmployeesList e on e.employee_ID = c.staff_id
             where c.counter_role = ? order by c.counter_no`,
            [req.session.user.role]
        );
        res.json(rows.map(r => ({
            counter: r.counter_no,
            occupied: !!r.occupied && r.staff_id !== req.session.user.id,
            staffName: r.occupied ? r.staff_name : null
        })));
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Counter Claim
router.post("/staff_claimCounter", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const counter = parseCounter(req.body.counter);
    if (!counter) {
        return res.status(400).json({ message: 'Invalid counter' });
    }
    const { id, role } = req.session.user;
    try {
        //One statement: take the counter only if it is free, stale, or already this staff member's
        const [result] = await db.query(
            `update Counters set staff_id = ?, last_seen = now(3), is_closed = 0
             where counter_role = ? and counter_no = ?
               and (staff_id is null or staff_id = ? or last_seen is null or last_seen < now(3) - interval 90 second)`,
            [id, role, counter, id]
        );
        if (result.affectedRows === 0) {
            return res.status(409).json({ message: 'That counter was just taken by another staff member.' });
        }
        //Let go of any other counter this staff member was holding
        await db.query(
            'update Counters set staff_id = null, last_seen = null, is_closed = 0 where staff_id = ? and not (counter_role = ? and counter_no = ?)',
            [id, role, counter]
        );
        res.json({ message: 'Counter claimed.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue Hold
router.patch("/staff_queueHold/:ticket", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.body.counter);
    const ticket = Number(req.params.ticket);
    if (!q || !counter || !Number.isInteger(ticket)) {
        return res.status(400).json({ message: 'Invalid request' });
    }
    try {
        const state = await counterState(req.session.user.role, counter);
        if (!state || state.staff_id !== req.session.user.id) {
            return notYourCounter(res);
        }
        const [result] = await db.query(
            `update ${q.table} set queue_status = 'held'
             where ${q.idCol} = ? and queue_status = 'serving' and counter_no = ?`,
            [ticket, counter]
        );
        if (result.affectedRows === 0) {
            return res.status(409).json({ message: 'That ticket is no longer being served at this counter.' });
        }
        res.json({ message: 'Ticket put on hold.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue Complete
router.patch("/staff_queueComplete/:ticket", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.body.counter);
    const ticket = Number(req.params.ticket);
    if (!q || !counter || !Number.isInteger(ticket)) {
        return res.status(400).json({ message: 'Invalid request' });
    }
    try {
        const state = await counterState(req.session.user.role, counter);
        if (!state || state.staff_id !== req.session.user.id) {
            return notYourCounter(res);
        }
        const [result] = await db.query(
            `update ${q.table} set queue_status = 'completed', completed_at = now()
             where ${q.idCol} = ? and queue_status = 'serving' and counter_no = ?`,
            [ticket, counter]
        );
        if (result.affectedRows === 0) {
            return res.status(409).json({ message: 'That ticket is no longer being served at this counter.' });
        }
        res.json({ message: 'Ticket completed.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue Resume
router.patch("/staff_queueResume/:ticket", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.body.counter);
    const ticket = Number(req.params.ticket);
    if (!q || !counter || !Number.isInteger(ticket)) {
        return res.status(400).json({ message: 'Invalid request' });
    }
    try {
        const state = await counterState(req.session.user.role, counter);
        if (!state || state.staff_id !== req.session.user.id) {
            return notYourCounter(res);
        }
        //Free counter: serve it now. Busy counter: back to the waiting list (it keeps its original place, since waiting is ordered by ticket number)
        const [busy] = await db.query(
            `select 1 from ${q.table}
             where queue_status = 'serving' and counter_no = ? and date_inquired >= curdate() limit 1`,
            [counter]
        );
        if (!busy.length && state.is_closed) {
            return res.status(409).json({ message: 'This counter is closed. Reopen it to resume a ticket.' });
        }
        const [result] = busy.length
            ? await db.query(
                `update ${q.table} set queue_status = 'waiting', counter_no = null
                 where ${q.idCol} = ? and queue_status = 'held' and counter_no = ?`,
                [ticket, counter]
            )
            : await db.query(
                `update ${q.table} set queue_status = 'serving', called_at = now()
                 where ${q.idCol} = ? and queue_status = 'held' and counter_no = ?`,
                [ticket, counter]
            );
        if (result.affectedRows === 0) {
            return res.status(409).json({ message: 'That ticket is no longer on hold.' });
        }
        res.json({ message: busy.length ? 'Ticket returned to the waiting list.' : 'Ticket is being served.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Queue Limit
router.patch("/staff_queueLimit", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const raw = req.body.limit;
    const limit = (raw === null || raw === '' || raw === undefined) ? null : Number(raw);
    if (limit !== null && (!Number.isInteger(limit) || limit < 1 || limit > 9999)) {
        return res.status(400).json({ message: 'Enter a whole number from 1 to 9999.' });
    }
    try {
        await db.query(
            'insert into QueueSettings (queue_role, daily_limit) values (?, ?) on duplicate key update daily_limit = ?',
            [req.session.user.role, limit, limit]
        );
        res.json({ limit });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

//Counter Closed
router.patch("/staff_counterClosed", requireRole('Registrar', 'Cashier'), async (req, res) => {
    const q = queueTableFor(req.session.user.role);
    const counter = parseCounter(req.body.counter);
    if (!q || !counter || typeof req.body.closed !== 'boolean') {
        return res.status(400).json({ message: 'Invalid request' });
    }
    const { id, role } = req.session.user;
    try {
        if (req.body.closed) {
            const [busy] = await db.query(
                `select 1 from ${q.table}
                 where queue_status = 'serving' and counter_no = ? and date_inquired >= curdate() limit 1`,
                [counter]
            );
            if (busy.length) {
                return res.status(409).json({ message: 'Complete or hold the current customer before closing this counter.' });
            }
        }
        const [result] = await db.query(
            'update Counters set is_closed = ?, last_seen = now(3) where counter_role = ? and counter_no = ? and staff_id = ?',
            [req.body.closed ? 1 : 0, role, counter, id]
        );
        if (result.affectedRows === 0) {
            return notYourCounter(res);
        }
        res.json({ closed: req.body.closed });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'storage error!' });
    }
})

module.exports = router;
