create database if not exists AcadilynxDB;

use AcadilynxDB;

create table if not exists CashierInquiries(
CInq_ID int auto_increment primary key not null,
inquirer_name varchar(60) not null,
student_name varchar(60) not null,
amount decimal(10,2) not null,
guardian_contact varchar(11) not null,
guardian_email varchar(60) not null,
services_selected text not null,
date_inquired timestamp(3) default current_timestamp(3) not null,
queue_status varchar(12) not null default 'waiting',
counter_no tinyint null,
called_at timestamp(3) null,
completed_at timestamp(3) null
) auto_increment = 10000;

create table if not exists RegistrarInquiries(
RInq_ID int auto_increment primary key not null,
inquirer_name varchar(60) not null,
student_name varchar(60) not null,
guardian_contact varchar(11) not null,
guardian_email varchar(50) not null,
services_selected text not null,
date_inquired timestamp(3) default current_timestamp(3) not null,
queue_status varchar(12) not null default 'waiting',
counter_no tinyint null,
called_at timestamp(3) null,
completed_at timestamp(3) null
) auto_increment = 20000;

create table if not exists EmployeesList(
employee_ID varchar(60) primary key not null,
employee_fullName varchar(60) not null,
employee_role varchar(60) not null,
employee_password varchar(255) not null,
employee_contact varchar(11) not null,
employee_email varchar(50) unique not null,
employee_status varchar(20) not null,
date_employed timestamp(3) default current_timestamp(3) not null
);

create table if not exists LoginLog(
login_ID int primary key not null,
employee_ID varchar(60) not null,
constraint fk_Employee
foreign key(employee_ID)
references EmployeesList(employee_ID),
login_stamp timestamp(6) default current_timestamp(6) not null
);

create table if not exists Students (
    student_id   unix_timestamp() not null auto_increment,
    student_name varchar(100) not null,
    grade_level  varchar(20)  not null,
    school_year  varchar(9)   not null,
    primary key (student_id),
    key idx_students_lookup (school_year, grade_level, student_name)
) engine=InnoDB default charset=utf8mb4;

create table if not exists Counters(
counter_role varchar(20) not null,
counter_no tinyint not null,
staff_id varchar(60) null,
last_seen timestamp(3) null,
is_closed tinyint(1) not null default 0,
txn_limit int null,
primary key (counter_role, counter_no)
);

insert ignore into Counters (counter_role, counter_no) values
('Registrar', 1), ('Registrar', 2), ('Registrar', 3),
('Cashier', 1), ('Cashier', 2), ('Cashier', 3);

create table if not exists QueueSettings(
queue_role varchar(20) primary key not null,
daily_limit int null
);
insert ignore into QueueSettings (queue_role) values ('Registrar'), ('Cashier');

create table if not exists Counters(
counter_role varchar(20) not null,
counter_no tinyint not null,
staff_id varchar(60) null,
last_seen timestamp(3) null,
is_closed tinyint(1) not null default 0,
txn_limit int null,
primary key (counter_role, counter_no)
);
insert ignore into Counters (counter_role, counter_no) values
('Registrar', 1), ('Registrar', 2), ('Registrar', 3),
('Cashier', 1), ('Cashier', 2), ('Cashier', 3);

alter table LoginLog modify login_ID int not null auto_increment;