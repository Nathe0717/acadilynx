const ESP32_URL = "http://10.151.199.91";


let currentService = '';
let guestData = { name: '', contactNumber: '' };
let enrolledData = { name: '', grade: '', schoolYear: '' };
let currentUserType = '';   // 'enrolled' | 'guest' - set when the "ARE YOU ENROLLED?" popup is verified
let kioskError = '';        // last error message from a kiosk fetch, shown in alerts
let isSubmitting = false;   // blocks double-tapping Confirm / Pay
let transactionData = {
    studentName: '',
    parentGuardian: '',
    contactNumber: '',
    email: '',
    transactionType: []
};

// ---------- code that actually calls the backend ----------
//For Navigation purposes. Paste the comments above the functions on the search bar.
//Code: fetch, endpoint, and database works, but it may be changed. It is already integrated into this client-side script.

//Post Registrar - fetch
async function sendRIdata(RIdata) {
    try {
        kioskError = '';
        console.log('received', RIdata);
        const response = await fetch('/kiosk/kiosk_RegistrarPost', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(RIdata)
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(result.message || 'HTTP error: ' + response.status);
        }

        console.log('server response: ', result);
        return result.idview;
    } catch (error) {
        console.error(error);
        kioskError = error.message;
    }
}

//Post Cashier - fetch
async function sendCIdata(CIdata) {
    try {
        kioskError = '';
        const response = await fetch('/kiosk/kiosk_CashierPost', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(CIdata)
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(result.message || 'HTTP error: ' + response.status);
        }

        console.log('server response: ', result);
        return result.idview;
    } catch (error) {
        console.error(error);
        kioskError = error.message;
    }
}

//Check Enrolled Student - fetch
async function checkEnrolledStudent(studentData) {
    try {
        kioskError = '';
        const response = await fetch('/kiosk/kiosk_VerifyStudent', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(studentData)
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
            throw new Error(result.message || 'HTTP error: ' + response.status);
        }

        console.log('server response: ', result);
        return result.found === true;
    } catch (error) {
        console.error(error);
        kioskError = error.message;
        return null;   // null = could not check (different from false = not found)
    }
}

//Queue status - fetch
async function checkQueueOpen(service) {
    try {
        const response = await fetch('/kiosk/kiosk_QueueStatus?queue=' + encodeURIComponent(service));
        if (!response.ok) return null;
        return await response.json();
    } catch (error) {
        console.error(error);
        return null;   // null = could not check; the ticket request still enforces the rules
    }
}

//Thermal printer (ESC/POS over WebUSB)
const PRINTER_COLS = 48;           // 48 for 80mm paper, 32 for 58mm
const encoder = new TextEncoder();
let printer = null;                // { device, endpointNumber }
let lastTicketNumber = '';       // set by confirmTransaction() / processPayment(), read by printReceipt()

async function openPrinter() {
    if (printer) return printer;

    // Reuse a printer the user already approved (silent after first pairing)
    let device = (await navigator.usb.getDevices())[0];
    if (!device) {
        // First time only: must be triggered by a click
        device = await navigator.usb.requestDevice({ filters: [{ classCode: 0x07 }] });
    }

    await device.open();
    if (!device.configuration) await device.selectConfiguration(1);

    // Find the first interface with a bulk OUT endpoint
    for (const iface of device.configuration.interfaces) {
        for (const alt of iface.alternates) {
            const ep = alt.endpoints.find(e => e.direction === 'out' && e.type === 'bulk');
            if (ep) {
                await device.claimInterface(iface.interfaceNumber);
                printer = { device, endpointNumber: ep.endpointNumber };
                return printer;
            }
        }
    }
    throw new Error('No writable endpoint found on printer');
}

//Session helpers (escape, inquirer info, reset)
function escapeHtml(v) {
    return String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function inquirerInfo() {
    if (currentUserType === 'enrolled') {
        return {
            inquirerType: 'enrolled',
            inquirerName: enrolledData.name
        };
    }
    return {
        inquirerType: 'guest',
        inquirerName: guestData.name,
        inquirerContact: guestData.contactNumber
    };
}

function prefillFromVerification() {
    const set = (id, v) => { const el = document.getElementById(id); if (el && v) el.value = v; };
    if (currentUserType === 'enrolled') {
        set('regStudentName', enrolledData.name);
        set('payStudentName', enrolledData.name);
    } else if (currentUserType === 'guest') {
        set('regParentGuardian', guestData.name);
        set('payPayerName', guestData.name);
        set('regContactNumber', guestData.contactNumber);
        set('payContactNumber', guestData.contactNumber);
    }
}

// ---------- Guest (not enrolled) service restrictions ----------
const GUEST_ALLOWED = { registrar: ['Others'], cashier: ['Other'] };
function applyServiceRestrictions() {
    const restrict = currentUserType === 'guest';
    const groups = [
        { selector: '#screen-inquiry input[name="inquiry-doc"]', allowed: GUEST_ALLOWED.registrar },
        { selector: '#screen-cashier input[name="fee"]', allowed: GUEST_ALLOWED.cashier }
    ];
    groups.forEach(g => document.querySelectorAll(g.selector).forEach(input => {
        const locked = restrict && !g.allowed.includes(input.value);
        input.disabled = locked;
        if (locked) input.checked = false;
        const row = input.closest('label');
        if (row) {
            row.style.opacity = locked ? '0.45' : '';
            row.style.cursor = locked ? 'not-allowed' : '';
            row.style.background = locked ? '#E4DECF' : '';
            row.style.borderColor = locked ? '#BDB4A0' : '';
        }
    }));
}

function resetKioskSession() {
    transactionData = { studentName: '', parentGuardian: '', contactNumber: '', email: '', transactionType: [] };
    guestData = { name: '', contactNumber: '' };
    enrolledData = { name: '', grade: '', schoolYear: '' };
    currentUserType = '';
    lastTicketNumber = '';
    document.querySelectorAll('#screen-registrar input, #screen-inquiry input, #screen-cashier input').forEach(i => {
        if (i.type === 'checkbox' || i.type === 'radio') i.checked = false;
        else if (i.type !== 'hidden') i.value = '';
    });
    applyServiceRestrictions();
}

// ---------- Kiosk (Kiosk) ----------
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');

    const isChatScreen = (id === 'screen-chatbot');
    document.getElementById('chatBackBtn').style.display = isChatScreen ? 'flex' : 'none';
    document.getElementById('chatbotSupportBtn').style.display = isChatScreen ? 'none' : 'flex';
    const navPill = document.getElementById('navPill');
    if (navPill) navPill.style.display = isChatScreen ? 'none' : 'flex';

    const showBackBtn = (id === 'screen-registrar' || id === 'screen-inquiry' || id === 'screen-transaction' || id === 'screen-cashier' || id === 'screen-payment-summary');
    if (id === 'screen-success-registrar' || id === 'screen-success-cashier' || isChatScreen) {
        document.getElementById('regBackBtn').style.display = 'none';
        return;
    }
    document.getElementById('regBackBtn').style.display = showBackBtn ? 'flex' : 'none';
    let backTarget = 'screen-home';
    if (id === 'screen-inquiry') backTarget = 'screen-registrar';
    if (id === 'screen-transaction') backTarget = 'screen-inquiry';
    if (id === 'screen-cashier') backTarget = 'screen-home';
    if (id === 'screen-payment-summary') backTarget = 'screen-cashier';
    document.getElementById('regBackBtn').setAttribute('onclick', "showScreen('" + backTarget + "')");
}

//Select service
async function selectService(service) {
    console.log('Selected service:', service);
    if (service === 'registrar' || service === 'cashier') {
        currentService = service;
        const status = await checkQueueOpen(service);
        if (status && status.open === false) {
            showQueueClosedPopup(status.message);
            return;
        }
        showEnrollmentQuestion();
        return;
    }
    if (service === 'chatbot') {
        showChatWelcome();
        showScreen('screen-chatbot');
        return;
    }
    alert('Selected: ' + service + '\n\n(Next: this will navigate to the ' + service + ' screen)');
}

//Chatbot
const REGISTRAR_LOCATION = 'The Registrar counter is on the ground floor, right past the main entrance.';
const CASHIER_LOCATION = 'The Cashier counter is on the ground floor, to the left of the main entrance, next to the waiting area.';

const CHAT_WELCOME = "<p>Hello! I'm your School Records Assistant. How can I help you today?</p>";

const CHAT_KB = [
    {
        id: 'request',
        question: 'How do I request school records?',
        keywords: ['how do i request', 'how to request', 'how can i request', 'request sf10', 'request form 137', 'request my child', 'request school records', 'request records', 'get my child', 'get sf10', 'get form 137', 'apply for', 'sf10', 'sf 10', 'form 137', 'form137', 'f137', 'request letter', 'request'],
        answer: "<p>To request your child's SF10 (Form 137), a <strong>request letter from the parent or guardian</strong> is required.</p><p><strong>Steps:</strong></p><ul><li>Prepare a request letter from the parent or guardian.</li><li>If the records are from another school, a request letter from that school may also be required.</li><li>Provide the student's full name, grade level, school year, and LRN, if available.</li><li>Submit your request to the registrar.</li></ul>"
    },
    {
        id: 'documents',
        question: 'What documents are required?',
        keywords: ['documents required', 'required documents', 'documents are required', 'what documents', 'which documents', 'what do i need', 'what to bring', 'need to bring', 'what should i bring', 'requirements', 'requirement', 'documents', 'bring', 'needed', 'prepare', 'is required', 'are required'],
        answer: "<p>For an SF10 (Form 137) request, please prepare:</p><ul><li>A request letter from the parent or guardian</li><li>A request letter from the other school, if the records are being requested from another school</li><li>The student's full name, grade level, school year, and LRN (Learner Reference Number), if available</li></ul><p>If another person will claim the records for you, additional documents are needed.</p>"
    },
    {
        id: 'time',
        question: 'How long does processing take?',
        keywords: ['how long', 'processing time', 'process time', 'how long does', 'processing', 'turnaround', 'how many days', 'how many weeks', 'working days', 'when will it be ready', 'when can i get', 'how soon', 'estimated time', 'days', 'weeks'],
        answer: "<p>Processing time depends on the request:</p><ul><li><strong>Certification only:</strong> usually 3-5 working days</li><li><strong>Needs extra verification or record retrieval:</strong> 1-2 weeks</li><li><strong>Records from another school, or discrepancies in student information:</strong> about 2 weeks or longer</li></ul><p>The registrar will give you an estimated completion date once your request is verified.</p>"
    },
    {
        id: 'fee',
        question: 'Are there any fees?',
        keywords: ['fee', 'fees', 'how much', 'cost', 'price', 'charge', 'charges', 'is there a fee', 'any fees', 'payment fee', 'free'],
        answer: "<p>Yes, fees may apply when requesting school records.</p><p>The registrar will inform you of the applicable fees. I can't give you an exact amount here, so please confirm it with the registrar.</p>"
    },
    {
        id: 'online',
        question: 'Can I request school records online?',
        keywords: ['online', 'submit online', 'online form', 'online request', 'request form', 'website', 'internet'],
        answer: "<p>Yes, you can request school records online.</p><p><strong>Steps:</strong></p><ul><li>Submit the online request form and the required documents.</li><li>The registrar verifies the student's information.</li><li>The registrar informs you of any applicable fees.</li><li>Follow the school's payment procedure.</li><li>The registrar processes your request and gives you an estimated completion date.</li><li>Wait for confirmation about the release of the records.</li></ul>"
    },
    {
        id: 'authorize',
        question: 'Can I authorize another person to claim the records?',
        keywords: ['authorize', 'authorise', 'authorization', 'authorization letter', 'authorized', 'representative', 'claim', 'someone else', 'another person', 'other person', 'on behalf', 'relative', 'lola', 'lolo', 'aunt', 'uncle', 'grandparent', 'sibling', 'claim for'],
        answer: "<p>Yes, you can authorize another person to claim your child's school records.</p><p>The authorized representative must bring:</p><ul><li>A signed authorization letter from the parent or guardian</li><li>A photocopy of the parent's or guardian's valid ID</li><li>A photocopy of the representative's valid ID</li><li>Proof of payment, when applicable</li></ul>"
    },
    {
        id: 'sent',
        question: 'Has my child\'s SF10 already been sent to the new school?',
        keywords: ['already sent', 'been sent', 'sent to', 'new school', 'receiving school', 'transferred', 'transfer', 'forwarded', 'was it sent', 'has it been sent', 'received by', 'confirm receipt', 'sent already'],
        answer: "<p>If the records have already been released and sent, please contact the receiving school to confirm that they received them.</p><p>To confirm whether the records were released, please contact the school registrar.</p>"
    },
    {
        id: 'pickup',
        question: 'Can I personally pick up the records?',
        keywords: ['personally', 'personally claim', 'pick up', 'pickup', 'pick it up', 'claim myself', 'claim it myself', 'get it myself', 'walk in', 'go to school'],
        answer: "<p>Yes. Parents or legal guardians may personally claim their child's school records, subject to the school's requirements and release procedures.</p>"
    },
    {
        id: 'notreleased',
        question: 'What if my child\'s records have not been released yet?',
        keywords: ['not released', 'not yet released', 'have not been released', 'havent been released', 'not been released', 'not released yet', 'delayed', 'delay', 'still waiting', 'havent received', 'not received', 'not yet received', 'taking so long', 'taking too long', 'long time', 'no update', 'late'],
        answer: "<p>We apologize for the delay. Please contact or visit the registrar's office to follow up on your request.</p><p>The registrar can check the records and update you on any pending requirements or the expected release date.</p>"
    },
    {
        id: 'track',
        question: 'How can I track my request?',
        keywords: ['follow up', 'followup', 'follow up on my request', 'track', 'tracking', 'track my request', 'status', 'check status', 'request status', 'where is my request', 'update on my request', 'check my request', 'status of my request'],
        answer: "<p>I can't see the live status of individual requests, so I can't tell you exactly where yours is.</p><p><strong>To follow up:</strong></p><ul><li>Contact or visit the registrar's office.</li><li>Give the student's full name and the date of your request.</li><li>The registrar will locate the record and give you an update.</li></ul>"
    },
    {
        id: 'sf9',
        question: 'What about SF9 (Form 138)?',
        keywords: ['sf9', 'sf 9', 'form 138', 'form138', 'f138', 'report card'],
        answer: "<p>I don't have specific details about SF9 (Form 138) requests. The registrar's office can give you the correct requirements and procedure.</p><p>I can help with questions about SF10 (Form 137) requests.</p>"
    },
    {
        id: 'paymentmethods',
        question: 'What payment methods are accepted?',
        keywords: ['gcash', 'paymaya', 'cash', 'payment method', 'payment methods', 'mode of payment', 'how to pay', 'how do i pay', 'accepted payment', 'pay'],
        answer: "<p>Payments can be made at the Cashier.</p><p><strong>Accepted:</strong></p><ul><li>Cash</li><li>GCash</li><li>PayMaya</li></ul>"
    },
    {
        id: 'hours',
        question: 'What are the office hours?',
        keywords: ['office hours', 'what time', 'operating hours', 'open', 'opening', 'closing', 'close', 'hours', 'operate', 'schedule'],
        answer: "<p>Our office hours are:</p><p>Monday &ndash; Friday: 8:00 AM &ndash; 5:00 PM</p><p>We are closed on Sundays and holidays.</p>"
    },
    {
        id: 'acctHours',
        question: 'What are the Accounting office hours?',
        keywords: ['accounting hours', 'accounting office hours', 'accounting office', 'accounting', 'accounting open'],
        answer: "<p>The Accounting office hours are:</p><p>Monday &ndash; Friday: 7:00 AM &ndash; 3:00 PM</p>"
    },
    {
        id: 'acctContact',
        question: 'How can I contact Accounting?',
        keywords: ['contact accounting', 'accounting contact', 'accounting number', 'contact number', 'viber', 'landline', 'phone number', 'call'],
        answer: "<p>You can reach Accounting through:</p><ul><li><strong>Viber:</strong> 0962-7266207</li><li><strong>Landline:</strong> 8-3515683</li></ul>"
    },
    {
        id: 'acctOnline',
        question: 'How do I pay online?',
        keywords: ['online payment', 'pay online', 'eastwest', 'eastwest bank', 'bank'],
        answer: "<p>Online payments are made through <strong>EastWest Bank, Corp.</strong></p>"
    },
    {
        id: 'acctTerms',
        question: 'What are the terms of payment?',
        keywords: ['terms of payment', 'payment terms', 'semestral', 'quarterly', 'monthly', 'installment'],
        answer: "<p>The accepted terms of payment are:</p><ul><li>Cash</li><li>Semestral</li><li>Quarterly</li><li>Monthly</li></ul>"
    },
    {
        id: 'enroll',
        question: 'How does enrollment work?',
        keywords: ['enrollment', 'enroll', 'enrolment', 're enroll', 'reenroll', 'new student', 'transferee', 'admission'],
        answer: "<p>Enrollment for the upcoming school year is now open.</p><p>New and transferee students should proceed to the Registrar counter with their requirements ready.</p><p>Continuing students may re-enroll directly at the Cashier for tuition and fee settlement.</p>"
    },
    {
        id: 'location',
        question: 'Where do I go?',
        keywords: ['where', 'location', 'located', 'directions', 'counter', 'where to go', 'find'],
        answer: "<p>" + REGISTRAR_LOCATION + "</p><p>" + CASHIER_LOCATION + "</p>"
    },
    {
        id: 'regloc',
        question: 'Where is the Registrar?',
        keywords: ['where is the registrar', 'where is registrar', 'registrar location', 'registrar counter', 'registrars office', 'registrar office'],
        answer: "<p>" + REGISTRAR_LOCATION + "</p>"
    },
    {
        id: 'cashloc',
        question: 'Where is the Cashier?',
        keywords: ['where is the cashier', 'where is cashier', 'cashier location', 'cashier counter', 'cashiers office', 'cashier office'],
        answer: "<p>" + CASHIER_LOCATION + "</p>"
    }
];

function chatFaq(id) {
    return CHAT_KB.find(f => f.id === id);
}

const CHAT_TOPICS = {
    'Requesting School Records': {
        faqs: ['request', 'documents', 'time', 'fee', 'online', 'authorize', 'pickup', 'sent', 'notreleased', 'track', 'sf9', 'regloc'],
        start: 'request'
    },
    'Where to go': {
        faqs: ['location', 'regloc', 'cashloc'],
        start: 'location'
    },
    'Office Hours': {
        faqs: ['hours', 'acctHours', 'acctContact'],
        start: 'hours'
    },
    'Payment & Fees': {
        faqs: ['paymentmethods', 'fee', 'acctOnline', 'acctTerms', 'cashloc'],
        start: 'paymentmethods'
    },
    'Enrollment Information': {
        faqs: ['enroll', 'regloc'],
        start: 'enroll'
    },
    'Other Questions': {
        faqs: [],
        start: null
    }
};

const CHAT_OTHER_ANSWER = '<p>For questions not covered here, please proceed to the Registrar or Cashier counter and a staff member will be happy to assist you directly.</p>';

let chatTopic = '';
let chatAsked = [];

function topicOfFaq(id) {
    return Object.keys(CHAT_TOPICS).find(t => CHAT_TOPICS[t].faqs.includes(id));
}

function faqReplies(ids) {
    return ids.map(id => ({ label: chatFaq(id).question, action: 'faq', id: id }));
}

function nextReplies(includeEnd) {
    const remaining = CHAT_TOPICS[chatTopic].faqs.filter(id => !chatAsked.includes(id)).slice(0, 2);
    const replies = faqReplies(remaining);
    if (includeEnd) {
        replies.push({ label: 'OK, Thank you!', action: 'thanks' });
    }
    replies.push({ label: 'Back to main menu', action: 'close' });
    return replies;
}

function answerFaq(faq) {
    if (!chatAsked.includes(faq.id)) chatAsked.push(faq.id);
    document.getElementById('chatFaqSelect').value = faq.id;
    addChatBubble('bot', faq.answer);
    setChatQuickReplies(nextReplies(true));
}

function buildFaqDropdown() {
    const select = document.getElementById('chatFaqSelect');
    const topicFaqs = CHAT_TOPICS[chatTopic].faqs;
    select.innerHTML = '';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = topicFaqs.length ? 'Select a question about ' + chatTopic + '...' : 'No FAQ questions in this topic';
    select.appendChild(placeholder);
    select.disabled = topicFaqs.length === 0;
    if (!topicFaqs.length) return;
    const ownGroup = document.createElement('optgroup');
    ownGroup.label = chatTopic;
    topicFaqs.forEach(id => {
        const option = document.createElement('option');
        option.value = id;
        option.textContent = chatFaq(id).question;
        ownGroup.appendChild(option);
    });
    select.appendChild(ownGroup);
    const others = CHAT_KB.filter(f => !topicFaqs.includes(f.id));
    const otherGroup = document.createElement('optgroup');
    otherGroup.label = 'Other topics';
    others.forEach(f => {
        const option = document.createElement('option');
        option.value = f.id;
        option.textContent = f.question;
        otherGroup.appendChild(option);
    });
    select.appendChild(otherGroup);
}

function handleFaqSelect(id) {
    if (!id) return;
    const faq = chatFaq(id);
    addChatBubble('user', faq.question);
    if (CHAT_TOPICS[chatTopic].faqs.includes(id)) {
        answerFaq(faq);
        return;
    }
    const target = topicOfFaq(id);
    document.getElementById('chatFaqSelect').value = '';
    addChatBubble('bot', '<p>That question is about <strong>' + target + '</strong>, which is outside <strong>' + chatTopic + '</strong>.</p><p>Would you like to switch topics?</p>');
    setChatQuickReplies([
        { label: 'Yes, switch to ' + target, action: 'switch', topic: target, id: id },
        { label: 'No, stay on ' + chatTopic, action: 'stay' },
        { label: 'Back to main menu', action: 'close' }
    ]);
}

function addChatBubble(role, html) {
    const row = document.createElement('div');
    row.className = 'chat-bubble-row ' + role;
    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble ' + role;
    bubble.innerHTML = html;
    row.appendChild(bubble);
    const messages = document.getElementById('chatMessages');
    messages.appendChild(row);
    messages.scrollTop = messages.scrollHeight;
}

function setChatQuickReplies(replies) {
    const container = document.getElementById('chatQuickReplies');
    container.innerHTML = '';
    replies.forEach(reply => {
        const btn = document.createElement('button');
        btn.className = 'chat-quick-reply-btn';
        btn.textContent = reply.label;
        btn.onclick = () => handleChatQuickReply(reply);
        container.appendChild(btn);
    });
}

function showChatWelcome() {
    chatTopic = '';
    chatAsked = [];
    document.getElementById('screen-chatbot').classList.remove('chat-active');
    document.getElementById('chatMessages').innerHTML = '';
    document.getElementById('chatQuickReplies').innerHTML = '';
    const select = document.getElementById('chatFaqSelect');
    select.innerHTML = '<option value="">Select a frequently asked question...</option>';
    select.disabled = false;
}

function clearChat() {
    if (!chatTopic) return;
    chatAsked = [];
    document.getElementById('chatMessages').innerHTML = '';
    document.getElementById('chatFaqSelect').value = '';
    addChatBubble('bot', CHAT_WELCOME);
    setChatQuickReplies(CHAT_TOPICS[chatTopic].faqs.length ? nextReplies(false) : [{ label: 'Back to main menu', action: 'close' }]);
}

function chatOption(topic) {
    chatTopic = topic;
    chatAsked = [];
    document.getElementById('screen-chatbot').classList.add('chat-active');
    document.getElementById('chatMessages').innerHTML = '';
    addChatBubble('bot', CHAT_WELCOME);
    buildFaqDropdown();
    const start = CHAT_TOPICS[topic].start;
    if (!start) {
        addChatBubble('user', 'I have another question.');
        addChatBubble('bot', CHAT_OTHER_ANSWER);
        setChatQuickReplies([
            { label: 'OK, Thank you!', action: 'thanks' },
            { label: 'Back to main menu', action: 'close' }
        ]);
        return;
    }
    const faq = chatFaq(start);
    addChatBubble('user', faq.question);
    answerFaq(faq);
}

function handleChatQuickReply(reply) {
    if (reply.action === 'thanks') {
        addChatBubble('user', 'Ok, Thank you!');
        addChatBubble('bot', "<p>You're welcome! \u{1F60A} I'm here if you need any more assistance.</p>");
        setChatQuickReplies([{ label: 'Back to main menu', action: 'close' }]);
    } else if (reply.action === 'faq') {
        const faq = chatFaq(reply.id);
        addChatBubble('user', faq.question);
        answerFaq(faq);
    } else if (reply.action === 'switch') {
        addChatBubble('user', reply.label);
        chatTopic = reply.topic;
        chatAsked = [];
        buildFaqDropdown();
        answerFaq(chatFaq(reply.id));
    } else if (reply.action === 'stay') {
        addChatBubble('user', reply.label);
        addChatBubble('bot', '<p>Okay! Let\'s continue with <strong>' + chatTopic + '</strong>.</p>');
        setChatQuickReplies(nextReplies(true));
    } else if (reply.action === 'close') {
        showChatWelcome();
    }
}
const popOverlay = document.getElementById('popOverlay');
const popCard = document.getElementById('popCard');
popOverlay.addEventListener('click', (e) => {
    if (e.target === popOverlay) closePopup();
});
function closePopup() {
    popOverlay.classList.remove('active');
    popCard.innerHTML = '';
}

function showQueueClosedPopup(message) {
    popCard.className = 'pop-card';
    popCard.innerHTML = `
        <button class="pop-close-x" onclick="closePopup()">&times;</button>
        <h2>QUEUE UNAVAILABLE</h2>
        <p class="pop-subtitle">${escapeHtml(message)}</p>
        <div class="pop-choice-row">
          <button class="pop-choice-btn pop-no" onclick="closePopup()">OK</button>
        </div>
      `;
    popOverlay.classList.add('active');
}

//Initial - service selection
//Should have a backend function for 'are you enrolled'. Wasn't fixed yet so backend function is not made yet.
function showEnrollmentQuestion() {
    popCard.className = 'pop-card';
    popCard.innerHTML = `
        <button class="pop-close-x" onclick="closePopup()">&times;</button>
        <h2>ARE YOU ENROLLED?</h2>
        <p class="pop-subtitle">Select an option to continue</p>
        <div class="pop-choice-row">
          <button class="pop-choice-btn pop-yes" onclick="showPopForm('enrolled')">Yes, I am</button>
          <button class="pop-choice-btn pop-no" onclick="showNotEnrolledForm()">No, I'm not</button>
        </div>
      `;
    popOverlay.classList.add('active');
}
function showNotEnrolledForm() {
    popCard.className = 'pop-card pop-registration-info';
    popCard.innerHTML = `
        <button class="pop-close-x" onclick="showEnrollmentQuestion()">&times;</button>
        <h2>YOUR DETAILS</h2>
        <form onsubmit="return submitNotEnrolledForm(event)">
          <div class="pop-form-group">
            <label>Full Name*</label>
            <input type="text" id="guestName" placeholder="Enter your full name" value="${escapeHtml(guestData.name)}" required>
          </div>
          <div class="pop-form-group">
            <label>Contact Number*</label>
            <input type="tel" id="guestContactNumber" inputmode="numeric" pattern="09[0-9]{9}" maxlength="11" placeholder="e.g. 09123456789" value="${escapeHtml(guestData.contactNumber)}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" required>
          </div>
          <div class="pop-details-action-row">
            <button type="button" class="pop-details-btn pop-cancel" onclick="showEnrollmentQuestion()">Cancel</button>
            <button type="submit" class="pop-details-btn pop-confirm">Confirm</button>
          </div>
        </form>
      `;
    document.getElementById('guestName').focus();
}
function submitNotEnrolledForm(e) {
    e.preventDefault();
    const name = document.getElementById('guestName').value.trim();
    const contact = document.getElementById('guestContactNumber').value.trim();
    if (!name) {
        alert('Please enter your full name.');
        return false;
    }
    if (!/^09[0-9]{9}$/.test(contact)) {
        alert('Please enter a valid contact number: 11 digits starting with 09.');
        return false;
    }
    guestData.name = name;
    guestData.contactNumber = contact;
    currentUserType = 'guest';
    verifyNotEnrolled();
    return false;
}
function verifyNotEnrolled() {
    popCard.className = 'pop-card pop-verified';
    popCard.innerHTML = `
        <h2>&#9989; USER VERIFIED!</h2>
        <a class="pop-continue-link" onclick="continueAfterVerification()">Click here to continue</a>
      `;
}
function schoolYearOptions() {
    let html = '';
    for (let year = 2020; year <= new Date().getFullYear(); year++) {
        const label = year + '-' + (year + 1);
        html += '<option value="' + label + '"' + (enrolledData.schoolYear === label ? ' selected' : '') + '>' + label + '</option>';
    }
    return html;
}
function showPopForm(type) {
    popCard.className = 'pop-card pop-registration-info';
    popCard.innerHTML = `
        <button class="pop-close-x" onclick="showEnrollmentQuestion()">&times;</button>
        <h2>STUDENT DETAILS</h2>
        <form onsubmit="return submitPopForm(event, 'enrolled')">
          <div class="pop-form-group">
            <label>Student Name*</label>
            <input type="text" id="enrolledName" placeholder="Enter student's full name" value="${escapeHtml(enrolledData.name)}" required>
          </div>
          <div class="pop-form-group">
            <label>Grade Level*</label>
            <input type="text" id="enrolledGrade" placeholder="e.g. Grade 6" value="${escapeHtml(enrolledData.grade)}" required>
          </div>
          <div class="pop-form-group">
            <label>School Year*</label>
            <select id="enrolledSchoolYear" required>
              <option value="" disabled ${enrolledData.schoolYear ? '' : 'selected'}>Select school year</option>
              ${schoolYearOptions()}
            </select>
          </div>
          <div class="pop-details-action-row">
            <button type="button" class="pop-details-btn pop-cancel" onclick="showEnrollmentQuestion()">Cancel</button>
            <button type="submit" class="pop-details-btn pop-confirm">Confirm</button>
          </div>
        </form>
      `;
    document.getElementById('enrolledName').focus();
}
//Checker
async function submitPopForm(e, type) {
    e.preventDefault();
    if (isSubmitting) return false;
    const name = document.getElementById('enrolledName').value.trim();
    const grade = document.getElementById('enrolledGrade').value.trim();
    const schoolYear = document.getElementById('enrolledSchoolYear').value.trim();
    if (!name || !grade || !schoolYear) {
        alert('Please complete all fields.');
        return false;
    }
    isSubmitting = true;
    const confirmBtn = e.target.querySelector('.pop-confirm');
    if (confirmBtn) confirmBtn.disabled = true;
    const found = await checkEnrolledStudent({ student: name, grade: grade, schoolYear: schoolYear });
    isSubmitting = false;
    if (confirmBtn) confirmBtn.disabled = false;
    if (found === null) {
        alert(kioskError || 'Could not check the student record. Please try again.');
        return false;
    }
    enrolledData.name = name;
    enrolledData.grade = grade;
    enrolledData.schoolYear = schoolYear;
    if (!found) {
        alert('We could not find that student. Please check the name, grade level and school year, or choose "No, I\'m not".');
        return false;
    }
    currentUserType = 'enrolled';
    popCard.className = 'pop-card pop-verified';
    popCard.innerHTML = `
        <h2>&#9989; USER VERIFIED!</h2>
        <a class="pop-continue-link" onclick="continueAfterVerification()">Click here to continue</a>
      `;
    return false;
}
function continueAfterVerification() {
    closePopup();
    prefillFromVerification();
    applyServiceRestrictions();
    if (currentService === 'registrar') {
        showScreen('screen-registrar');
    } else if (currentService === 'cashier') {
        showScreen('screen-cashier');
    }
}
function handleRegistrationSubmit(e) {
    e.preventDefault();
    const contact = document.getElementById('regContactNumber').value.trim();
    if (!/^09[0-9]{9}$/.test(contact)) {
        alert('Please enter a valid contact number: 11 digits starting with 09.');
        return false;
    }
    transactionData.studentName = document.getElementById('regStudentName').value;
    transactionData.parentGuardian = document.getElementById('regParentGuardian').value;
    transactionData.contactNumber = contact;
    transactionData.email = document.getElementById('regEmail').value;
    showScreen('screen-inquiry');
    return false;
}
function handleInquirySubmit(e) {
    e.preventDefault();
    const selected = Array.from(document.querySelectorAll('#screen-inquiry input[name="inquiry-doc"]:checked')).map(el => el.value);
    if (selected.length === 0) {
        alert('Please select at least one document.');
        return false;
    }
    if (currentUserType === 'guest' && selected.some(v => !GUEST_ALLOWED.registrar.includes(v))) {
        alert('Only Form 137 is available for students who are not enrolled.');
        return false;
    }
    transactionData.transactionType = selected;
    populateTransactionDetails();
    showScreen('screen-transaction');
    return false;
}
function handleCashierSubmit(e) {
    e.preventDefault();
    const selectedFees = Array.from(document.querySelectorAll('#screen-cashier input[name="fee"]:checked')).map(el => el.value);
    if (selectedFees.length === 0) {
        alert('Please select at least one fee.');
        return false;
    }
    if (currentUserType === 'guest' && selectedFees.some(v => !GUEST_ALLOWED.cashier.includes(v))) {
        alert('Only "Other" is available for students who are not enrolled.');
        return false;
    }
    const contact = document.getElementById('payContactNumber').value.trim();
    if (!/^09[0-9]{9}$/.test(contact)) {
        alert('Please enter a valid contact number: 11 digits starting with 09.');
        return false;
    }
    transactionData.studentName = document.getElementById('payStudentName').value;
    transactionData.parentGuardian = document.getElementById('payPayerName').value;
    transactionData.contactNumber = contact;
    transactionData.email = document.getElementById('payEmail').value;
    transactionData.transactionType = selectedFees;
    populatePaymentSummary();
    showScreen('screen-payment-summary');
    return false;
}

function populatePaymentSummary() {
    const rowsContainer = document.getElementById('summaryRows');
    rowsContainer.innerHTML = '';
    transactionData.transactionType.forEach(fee => {
        const row = document.createElement('div');
        row.className = 'summary-row';
        const label = document.createElement('span');
        label.textContent = fee;
        const wrap = document.createElement('div');
        wrap.className = 'summary-amount-wrap';
        const peso = document.createElement('span');
        peso.innerHTML = '&#8369;';
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'summary-amount-input';
        input.setAttribute('inputmode', 'decimal');
        input.setAttribute('placeholder', '0');
        input.setAttribute('aria-label', fee + ' amount');
        input.addEventListener('input', () => {
            let v = input.value.replace(/[^0-9.]/g, '');
            const firstDot = v.indexOf('.');
            if (firstDot !== -1) {
                v = v.slice(0, firstDot + 1) + v.slice(firstDot + 1).replace(/\./g, '').slice(0, 2);
            }
            input.value = v;
            updateSummaryTotal();
        });
        wrap.appendChild(peso);
        wrap.appendChild(input);
        row.appendChild(label);
        row.appendChild(wrap);
        rowsContainer.appendChild(row);
    });
    updateSummaryTotal();
    document.getElementById('paymentMethod').value = '';
}

function updateSummaryTotal() {
    let total = 0;
    document.querySelectorAll('#summaryRows .summary-amount-input').forEach(input => {
        total += parseFloat(input.value) || 0;
    });
    document.getElementById('summaryTotal').innerHTML = '&#8369; ' + total.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

//Post Cashier
async function processPayment() {
    if (isSubmitting) return;
    const amountInputs = Array.from(document.querySelectorAll('#summaryRows .summary-amount-input'));
    if (amountInputs.some(input => !(parseFloat(input.value) > 0))) {
        alert('Please enter an amount for each selected fee.');
        return;
    }
    const method = document.getElementById('paymentMethod').value;
    if (!method) {
        alert('Please select a payment method.');
        return;
    }
    let total = 0;
    amountInputs.forEach(input => {
        total += parseFloat(input.value) || 0;
    });
    total = Math.round(total * 100) / 100;
    isSubmitting = true;
    const insertCash = await sendCIdata({
        student: transactionData.studentName,
        guardian: transactionData.parentGuardian,
        fee: total,
        contact: transactionData.contactNumber,
        email: transactionData.email,
        transactions: transactionData.transactionType.join(', '),
        ...inquirerInfo()
    });
    isSubmitting = false;
    if (insertCash === undefined) {
        alert(kioskError || 'Could not save the payment. Please try again.');
        return;
    }
    lastTicketNumber = insertCash;
    document.getElementById('cashierTicketNumber').textContent = insertCash;
    showScreen('screen-success-cashier');
}

function buildReceipt(ticketNumber) {
    const out = [];
    const raw = (...b) => out.push(...b);
    const text = s => out.push(...encoder.encode(s));
    const line = (s = '') => text(s + '\n');

    const now = new Date();
    const dateStr = now.toLocaleDateString();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    raw(0x1B, 0x40);                       // initialize
    raw(0x1B, 0x61, 1);                    // center

    line('TICKET NUMBER');
    raw(0x1B, 0x45, 1);                    // bold on
    raw(0x1D, 0x21, 0x33);                 // 4x width + height
    line(String(ticketNumber));
    raw(0x1D, 0x21, 0x00);                 // normal size
    raw(0x1B, 0x45, 0);                    // bold off

    line();
    line('Date: ' + dateStr);
    line('Time: ' + timeStr);
    line();
    line();
    raw(0x1D, 0x56, 0x42, 0x03);           // feed + partial cut
    return new Uint8Array(out);
}

function bytesToBase64(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
}

function printReceipt() {
    if (!lastTicketNumber) {
        alert('No ticket to print.');
        return;
    }
    const data = buildReceipt(lastTicketNumber);
    window.location.href = 'rawbt:base64,' + bytesToBase64(data);
}

function doneRegistrarTransaction() {
    resetKioskSession();
    showScreen('screen-home');
}

function doneCashierTransaction() {
    resetKioskSession();
    showScreen('screen-home');
}
function populateTransactionDetails() {
    document.getElementById('txnStudentName').textContent = transactionData.studentName;
    document.getElementById('txnParentGuardian').textContent = transactionData.parentGuardian;
    document.getElementById('txnTransactionType').textContent = transactionData.transactionType.join('/ ');
}
function editDetails() {
    document.getElementById('regStudentName').value = transactionData.studentName;
    document.getElementById('regParentGuardian').value = transactionData.parentGuardian;
    document.getElementById('regContactNumber').value = transactionData.contactNumber;
    document.getElementById('regEmail').value = transactionData.email;
    showScreen('screen-registrar');
}
//Post Registrar
async function confirmTransaction() {
    if (isSubmitting) return;
    isSubmitting = true;
    const insertReg = await sendRIdata({
        student: transactionData.studentName,
        guardian: transactionData.parentGuardian,
        contact: transactionData.contactNumber,
        email: transactionData.email,
        transactions: transactionData.transactionType.join(', '),
        ...inquirerInfo()
    });
    isSubmitting = false;
    if (insertReg === undefined) {
        alert(kioskError || 'Could not save the transaction. Please try again.');
        return;
    }
    lastTicketNumber = insertReg;
    document.getElementById('regTicketNumber').textContent = insertReg;
    showScreen('screen-success-registrar');
}
function cancelTransaction() {
    resetKioskSession();
    showScreen('screen-home');
}

//Contact boxes: digits only, 11 characters
['regContactNumber', 'payContactNumber'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.maxLength = 11;
    el.inputMode = 'numeric';
    el.addEventListener('input', () => { el.value = el.value.replace(/[^0-9]/g, ''); });
});

//Name boxes: letters, spaces and . ' - only (no numbers or other symbols), 2 letters minimum, 60 characters maximum
const NAME_FIELD_IDS = ['regStudentName', 'regParentGuardian', 'payStudentName', 'payPayerName', 'guestName', 'enrolledName'];
const NAME_OK = /^(?=(?:.*\p{L}){2})[\p{L}\s.'’-]+$/u;
const NAME_MESSAGE = "Please enter a valid name: letters, spaces, and . ' - only.";

//The popup boxes are created later, so the rules are attached to the whole page instead of to each box
document.addEventListener('focusin', e => {
    if (NAME_FIELD_IDS.includes(e.target.id)) e.target.maxLength = 60;
});
document.addEventListener('input', e => {
    const el = e.target;
    if (!NAME_FIELD_IDS.includes(el.id)) return;
    //Remove numbers and symbols as they are typed or pasted
    const cleaned = el.value.replace(/[^\p{L}\s.'’-]/gu, '');
    if (cleaned !== el.value) el.value = cleaned;
    //Block the form the way a missing @ does (the browser shows this message)
    const name = el.value.trim();
    el.setCustomValidity(name === '' || NAME_OK.test(name) ? '' : NAME_MESSAGE);
});