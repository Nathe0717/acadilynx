//Daily queue reset, done at the start of the next day's use instead of at midnight.
//The server PC is usually off (or asleep) at midnight, so nothing here depends on a midnight clock.
//It runs when the server starts, and then checks every 5 minutes whether the calendar day (Manila time)
//has changed since the last reset. This also catches a PC that was put to sleep and woken up the next morning.
//Each reset deletes every ticket from before today, restarts ticket numbering when a table ends up empty
//(Registrar from 20000, Cashier from 10000), and frees all counters.
const db = require("../db/devAConnectionWU");

const TABLES = [
    { table: 'RegistrarInquiries', startAt: 20000 },
    { table: 'CashierInquiries', startAt: 10000 }
];

const CHECK_EVERY_MS = 5 * 60 * 1000;
let lastResetDay = null;

function manilaToday() {
    return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Manila' }); // YYYY-MM-DD
}

async function purgeOldTickets() {
    try {
        for (const { table, startAt } of TABLES) {
            const [result] = await db.query(`delete from ${table} where date_inquired < curdate()`);
            const [[left]] = await db.query(`select count(*) as n from ${table}`);
            if (left.n === 0) {
                //Safe to restart numbering: nothing is left that could clash
                await db.query(`alter table ${table} auto_increment = ${startAt}`);
            }
            if (result.affectedRows) console.log('[queue reset] removed', result.affectedRows, 'old tickets from', table);
        }
        //Nobody should keep a counter (or a closed counter) from yesterday
        await db.query('update Counters set staff_id = null, last_seen = null, is_closed = 0');
        lastResetDay = manilaToday();
    } catch (error) {
        console.error('[queue reset] failed (will retry):', error);
    }
}

function start() {
    purgeOldTickets();
    setInterval(() => {
        if (manilaToday() !== lastResetDay) purgeOldTickets();
    }, CHECK_EVERY_MS);
}

module.exports = { start, purgeOldTickets };
