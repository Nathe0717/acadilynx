const db = require("../db/devAConnectionWU");

function requireRole(...roles) {
    return async (req, res, next) => {
        const user = req.session && req.session.user;
        if (!user) return res.status(401).json({ message: 'Not logged in.' });
        if (!roles.includes(user.role)) return res.status(403).json({ message: 'Not allowed.' });
        try {
            const [rows] = await db.query('select employee_status from EmployeesList where employee_ID = ?', [user.id]);
            if (!rows.length || rows[0].employee_status !== 'active') {
                req.session.destroy(() => { });
                return res.status(401).json({ message: 'Account is not active.' });
            }
            next();
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'storage error!' });
        }
    };
}

module.exports = requireRole;