//Tiny in-memory rate limiter (no extra package needed).
//Usage: router.post('/x', rateLimit({ max: 20, windowMs: 10 * 60 * 1000, message: '...' }), handler)
//Counts requests per client IP inside a sliding window. Resets when the server restarts.
function rateLimit({ max, windowMs, message }) {
    const hits = new Map();
    return (req, res, next) => {
        const now = Date.now();
        const key = req.ip;
        const recent = (hits.get(key) || []).filter(t => now - t < windowMs);
        if (recent.length >= max) {
            hits.set(key, recent);
            return res.status(429).json({ message: message || 'Too many attempts. Please wait a moment and try again.' });
        }
        recent.push(now);
        hits.set(key, recent);
        //Occasionally drop clients that have gone quiet so the map cannot grow forever
        if (hits.size > 500) {
            for (const [k, list] of hits) {
                if (!list.some(t => now - t < windowMs)) hits.delete(k);
            }
        }
        next();
    };
}

module.exports = rateLimit;
