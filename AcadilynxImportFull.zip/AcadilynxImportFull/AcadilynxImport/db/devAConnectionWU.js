const mysql =
    require('mysql2/promise');
    require('dotenv').config({ path: './database_info.env' });

//connection
let con = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, //remove/change after testing.
    database: process.env.DB_NAME //database
});

async function connectDB() {
    try {
        await con.connect();
        console.log('Connected to database');
    } catch(err) {
        console.error('Error connecting to MySQL: ', err.message);
    }
}

module.exports = con;